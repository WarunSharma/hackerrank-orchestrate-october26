import { outputPath } from "./config.js";
import { generateRows, writeOutput } from "./planner.js";

const result = await generateRows();
if (result.unresolvedCases.length > 0) {
  throw new Error(`Refusing to write ${outputPath}: unresolved evidence for ${result.unresolvedCases.length} cases (${result.unresolvedCases.join(", ")})`);
}
writeOutput(result.rows);
console.log(`Wrote ${result.rows.length} deterministic audit rows to ${outputPath}`);
